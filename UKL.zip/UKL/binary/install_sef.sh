#!/run/current-system/sw/bin/bash
cd $local_dir/python/sefcontext-parser
python3 setup.py install
